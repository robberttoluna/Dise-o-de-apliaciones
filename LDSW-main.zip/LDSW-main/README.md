El proyecto fué nombrado 'movies_cat' como abreviación de Movies catalogue. lib/main.dart contiene la act.

Diseño de aplicaciones móviles
Carlos Alberto Rodriguez Garcia 
